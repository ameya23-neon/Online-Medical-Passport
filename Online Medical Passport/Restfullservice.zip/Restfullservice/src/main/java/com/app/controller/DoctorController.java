package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Description;
import com.app.pojos.Users;
import com.app.service.IDescriptionService;
import com.app.service.IDoctorService;
import com.app.service.IUserService;

@RestController
@RequestMapping("/doctors")
public class DoctorController {

	@Autowired
	private IDoctorService service;
	
	@Autowired
	private IUserService userservice;
	
	
	@Autowired
	private IDescriptionService descriptionservice;
	
	public DoctorController() {
		System.out.println("In Doctor Controller"+getClass().getName());
	}
	
	  @GetMapping("/users")
	  public ResponseEntity<?> listAllUsers() {
	  System.out.println("in list of all users");
	  List<Users> users=userservice.getAllUsers(); 
	  if(users.isEmpty()) 
		  return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
	  return new ResponseEntity<>(users,HttpStatus.OK); 
	  }	 
	
	

		@PostMapping("/users")
		public ResponseEntity<?> addNewUser(@RequestBody Users u ) {
			System.out.println("in add new user " + u);
			return ResponseEntity.ok(userservice.addUserDetails(u));
		}
		
		
		@PostMapping("/users/description")
		public  ResponseEntity<?>assignDescription(@RequestBody Description description) 
		{
		  System.out.println("Assign description"+description+" "+description.getUserdetails());
		  return ResponseEntity.ok(userservice.assignDescription(description));
		  
		  }
		 
		

		@GetMapping("/userbymail/{email}")
	public ResponseEntity<?>getUserDetails(@PathVariable String email)
	{
			System.out.println("Get user Details"+email);
			try {
				
				Users u=userservice.getUserDetails(email);
				return new ResponseEntity<Users>(u,HttpStatus.OK);
				
			}catch (Exception e) {
				return new ResponseEntity<String>("User Not Found",HttpStatus.OK);
			}
	}	
		
		@PutMapping("/description/{descriptionId}")
		public ResponseEntity<?>updateDescriptionDetails(@PathVariable int descriptionId,@RequestBody Description d)
		{
			System.out.println("in update"+descriptionId+" "+d);
			try {
				Description updatedetails=descriptionservice.updateDescription(descriptionId,d);
				return new ResponseEntity<>(updatedetails,HttpStatus.OK);
			}catch (RuntimeException e) {
				e.printStackTrace();
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
				
			}
		}
		
		
		
}
