package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.pojos.Doctors;
import com.app.pojos.Users;

public interface IDoctorService {

	
	List<Doctors>listAllDoctors();
	Optional<Doctors>findByName(String dName);
	Doctors getDoctorrDetailsById(int doctorId);
	Doctors registerdDoctor(Doctors trannsientDoctor);
}
