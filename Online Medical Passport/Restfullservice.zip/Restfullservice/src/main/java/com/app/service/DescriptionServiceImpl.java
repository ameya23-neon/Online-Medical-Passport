package com.app.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.cust_excs.UserNotFoundException;
import com.app.dao.DescriptionRepository;
import com.app.pojos.Description;


@Service
@Transactional
public class DescriptionServiceImpl implements IDescriptionService {

	
	@Autowired
	private DescriptionRepository descriptionrep;
	
	@Override
	public Description updateDescription(int descriptionId, Description d1) {
		// TODO Auto-generated method stub
		Optional<Description>d=descriptionrep.findById(descriptionId);
		if(d.isPresent())
		{
			Description description=d.get();
			description.setAge(d1.getAge());
			description.setAllergies(d1.getAllergies());
			description.setBloodPressure(d1.getBloodPressure());
			description.setHeartRate(d1.getHeartRate());
			description.setHeight(d1.getHeight());
			description.setMedicalhistory(d1.getMedicalhistory());
			description.setLastcheckupdate(d1.getLastcheckupdate());
			description.setOxygenLevel(d1.getOxygenLevel());
			description.setUpcomingcheckupdate(d1.getUpcomingcheckupdate());
			description.setUserdetails(d1.getUserdetails());
			description.setSelectdoctor(d1.getSelectdoctor());
			return description;
		}
		throw new UserNotFoundException("Invalid Description Id");
	}

	
}
