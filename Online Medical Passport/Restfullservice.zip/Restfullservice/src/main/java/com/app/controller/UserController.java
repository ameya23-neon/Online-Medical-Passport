package com.app.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Users;
import com.app.service.IUserService;

@RestController //cla s level annotation +@Responce Body anno added on types of all req handling methods
@RequestMapping("/users")
public class UserController {
	

	  @Autowired 
	  private IUserService service;
	  
	  public UserController() {
	  System.out.println("In User Controlller"+getClass().getName()); 
	 }	  

		//add new REST end point : to add a user
		@PostMapping
		public ResponseEntity<?> addNewUser(@RequestBody Users u ) {
			System.out.println("in add new user " + u);
			return ResponseEntity.ok(service.addUserDetails(u));
		}

}
