package com.app.service;

import com.app.pojos.Description;

public interface IDescriptionService {

	
	Description updateDescription(int descriptionId,Description detachedPOJO);
	
}
