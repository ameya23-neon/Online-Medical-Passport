package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfullserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfullserviceApplication.class, args);
	}

}
