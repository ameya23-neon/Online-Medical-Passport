package com.app.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.app.pojos.Users;
@Repository
public class UserDaoImpl implements IUserDao{

	@PersistenceContext
	private EntityManager mgr;

	
	@Override
	public Users getUserDetails(String email) {
		System.out.println("In getUserDetails ");
		String jpql="select u from Users u where u.email=:email";
		return mgr.createQuery(jpql,Users.class).setParameter("email",email). getSingleResult();
	}
	
	
	
}
