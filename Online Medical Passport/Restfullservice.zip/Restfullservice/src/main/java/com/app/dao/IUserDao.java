package com.app.dao;

import com.app.pojos.Users;

public interface IUserDao {

	Users getUserDetails(String email); 
}
